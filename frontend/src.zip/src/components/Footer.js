import React from 'react'
import  './footer.css';
export default function Footer() {
  return (
    <div>
      <footer>
            <p>&copy;2025 to be begun with HappyPaws</p>
       </footer>
    </div>
  )
}
