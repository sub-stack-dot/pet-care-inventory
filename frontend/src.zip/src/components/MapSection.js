{/*import React from 'react'
import'./mapsection.css';

export default function MapSection() {
  return (
    <div className="map-container">
    <iframe
      className="map-frame"
      title="Google Map"
      src= "https://maps.google.com/maps?width=720&amp;height=600&amp;hl=en&amp;q=faculty%20of%20Engineering,%20University%20of%20Ruhuna,%20Galle,%20Sri%20Lanka+(Happy%20Paws)&amp;t=&amp;z=15&amp;ie=UTF8&amp;iwloc=B&amp;output=embed">
        <a href="https://www.gps.ie/">gps vehicle tracker</a></iframe>
      {/*allowFullScreen=loading="lazy"*
    <div className="map-info">
      <h3>Happy Paws</h3>
    </div>
  </div>
  )
}
*/}